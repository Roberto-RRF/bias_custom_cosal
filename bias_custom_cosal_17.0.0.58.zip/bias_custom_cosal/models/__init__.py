# -*- coding: utf-8 -*-

from . import product_attribute
from . import product_attribute_value
from . import product_product
from . import mrp_production
from . import sale_order


# -*- coding: utf-8 -*-
from . import sale_product_configuration
